<!DOCTYPE html>
<html>
<head>
	<title></title>
	<?php 
		get_stylesheet(); 
		get_javaScript();
	?>
	
</head>
<body>

